一个简易的搜索大全页面
----

[react版demo](http://github.com/lavyun/react-demo-search)

* [演示地址](http://lavyun.github.io/vue-demo-search)

#### 所用知识
- 单文件组件
- vue-resource(ajax库)
- vue过渡效果

#### 如何运行
将本项目下载的本地.
> 1. 需要node环境
> 2. 输入命令npm install(最好使用cnpm淘宝镜像)
> 3. 输入命令npm run dev
